var i = 1, sum = 0;
var numArray = [0, 1];
fib = (num) =>{
    
    if (num < 1){
        document.getElementById("result").innerHTML = numArray;
    } else 
    { 
        
        sum = numArray[i] + numArray[i-1];
        if (sum < num){
        numArray.push(sum);
        i += 1;
        fib(num);
        }
    }
document.getElementById("result").innerHTML = numArray;
};

