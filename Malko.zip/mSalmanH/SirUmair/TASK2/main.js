const arr = [2, 10, -5, 3, -8];
var sum = 0;
arr.forEach(Add);
function Add(num){
    if (num>=0){
        sum += num;
    }
}
document.getElementById("result").innerHTML= sum ;