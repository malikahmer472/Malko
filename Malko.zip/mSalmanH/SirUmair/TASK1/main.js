checkNum =() => {
let num = document.getElementById("input").value;
if (num > 0){
    document.getElementById("number").innerHTML = "Number is Positive";
} else if (num < 0){
    document.getElementById("number").innerHTML = "Number is Negative";
} else { 
    document.getElementById("number").innerHTML = "Number is Equals to Zero";
}
}