var numArray = [];
var mainArray = [];
c =() =>{
    numArray = [];
    mainArray = [];
    document.getElementById("inp").value = 0;
}
plusMinus =() =>{
    var joinedArray = numArray.join('');
    while (numArray.length) {
        numArray.pop();
    }
    numArray.push(parseFloat(joinedArray));
    mainArray.push(numArray);
    numArray=[];
    mainArray.push('±');
    document.getElementById("inp").value = '±';
}
nine =() =>{
    numArray.push(9);
    let comaRemover = numArray.join('');
    document.getElementById("inp").value = comaRemover;
}
consle =() =>{
    console.log(mainArray);
    mainArray = [];
}
seven =() =>{
    numArray.push(7);
    let comaRemover = numArray.join('');
    document.getElementById("inp").value = comaRemover;
}
eight =() =>{
    numArray.push(8);
    let comaRemover = numArray.join('');
    document.getElementById("inp").value = comaRemover;
}
percent =() =>{
    var joinedArray = numArray.join('');
    while (numArray.length) {
        numArray.pop();
    }
    numArray.push(parseFloat(joinedArray));
    mainArray.push(numArray);
    numArray=[];
    mainArray.push('%');
    document.getElementById("inp").value = '%';
}
divide =() =>{
    var joinedArray = numArray.join('');
    while (numArray.length) {
        numArray.pop();
    }
    numArray.push(parseFloat(joinedArray));
    mainArray.push(numArray);
    numArray=[];
    mainArray.push('÷');
    document.getElementById("inp").value = '÷';
}
four =() =>{
    numArray.push(4);
    let comaRemover = numArray.join('');
    document.getElementById("inp").value = comaRemover;
}
five =() =>{
    numArray.push(5);
    let comaRemover = numArray.join('');
    document.getElementById("inp").value = comaRemover;
}
six =() =>{
    numArray.push(6);
    let comaRemover = numArray.join('');
    document.getElementById("inp").value = comaRemover;
}
multiply =() =>{
    if (typeof(numArray[0]) == 'number'){ 
        mainArray.push(numArray);
        numArray=[];
        mainArray.push('×');
        document.getElementById("inp").value = '×';
    }
    else
    {
    var joinedArray = numArray.join('');
    while (numArray.length) {
        numArray.pop();
    }
    numArray.push(parseFloat(joinedArray));
    mainArray.push(numArray);
    numArray=[];
    mainArray.push('×');
    document.getElementById("inp").value = '×';
    console.log(mainArray);
   
    }

}
   
one =() =>{
    numArray.push(1);
    let comaRemover = numArray.join('');
    document.getElementById("inp").value = comaRemover;
}
two =() =>{
    numArray.push(2);
    let comaRemover = numArray.join('');
    document.getElementById("inp").value = comaRemover;
}
three =() =>{
    numArray.push(3);
    let comaRemover = numArray.join('');
    document.getElementById("inp").value = comaRemover;
}
minus =() =>{
    var joinedArray = numArray.join('');
    while (numArray.length) {
        numArray.pop();
    }
    numArray.push(parseFloat(joinedArray));
    mainArray.push(numArray);
    numArray=[];
    mainArray.push('-');
    document.getElementById("inp").value = '-';
}
zero =() =>{
    numArray.push(0);
    let comaRemover = numArray.join('');
    document.getElementById("inp").value = comaRemover;
}
dot =() =>{

    numArray.push('.');
    let comaRemover = numArray.join('');
    document.getElementById("inp").value = comaRemover;
}
equal =() =>{   
    var joinedArray = numArray.join('');
    while (numArray.length) {
        numArray.pop();
    }
    numArray.push(parseFloat(joinedArray));
    mainArray.push(numArray);
    numArray=[]; 
    console.log(mainArray);
     for (i=0; i<=mainArray.length; i++){
      
            switch (mainArray[i+1]){
                case '±':
                    let pm = mainArray[0] + mainArray[2];
                    mainArray.splice(0,3);
                    mainArray[0] = pm;
                break;
                case '%':
                    let pm1 = mainArray[0] % mainArray[2];
                    mainArray.splice(0,3);
                    mainArray[0] = pm1;
                break;
                case '×':
                    let pm2 = parseFloat(mainArray[0]) * parseFloat(mainArray[2]);
                    mainArray.splice(0,2);
                    mainArray[0] = pm2;
                break;
                case '-':
                    let pm3 = mainArray[0] - mainArray[2];
                    mainArray.splice(0,3);
                    mainArray[0] = pm3;
                break;
                case '+':
                    let pm4 = mainArray[0] + mainArray[2];
                    mainArray.splice(0,3);
                    mainArray[0] = pm4;
                   
                break;
            }
               
    }
    let resVal = mainArray[0];
    mainArray = [];
    document.getElementById("inp").value = resVal;
    console.log(typeof(resVal));
    console.log(resVal);
    
}
plus =() =>{
    var joinedArray = numArray.join('');
    while (numArray.length) {
        numArray.pop();
    }
    numArray.push(parseFloat(joinedArray));
    mainArray.push(numArray);
    numArray=[];
    mainArray.push('+');
    document.getElementById("inp").value = '+';
}
